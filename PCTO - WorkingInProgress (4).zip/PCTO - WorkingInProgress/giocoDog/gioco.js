// --- VARIABILI GLOBALI (invariate) ---
let video;
let handpose;
let hands = [];
let cursor = { x: 0, y: 0 };
let pinchState = false;
let ultimoPinch = false;

let imgSfondo, imgCono;
let imgsGelato = {}; 

let coni = [
  ['marrone', 'giallo', 'verde', 'rosa'],
  ['verde', 'rosa', 'marrone', 'giallo'],
  ['giallo', 'marrone', 'rosa', 'verde'],
  ['marrone', 'giallo', 'verde', 'rosa'],
  [],
  []
];

let selezione = { attiva: false, indiceCono: -1, gusto: null };
let vittoria = false;

function preload() {
  imgSfondo = loadImage('sfondo.png');
  imgCono = loadImage('cono.png');
  imgsGelato['rosa'] = loadImage('rosa.png');
  imgsGelato['verde'] = loadImage('verde.png');
  imgsGelato['bianco'] = loadImage('bianco.png');
  imgsGelato['giallo'] = loadImage('giallo.png');
  imgsGelato['marrone'] = loadImage('marrone.png');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  let options = { maxHands: 1, runtime: 'mediapipe', flipHorizontal: true };
  handpose = ml5.handPose(video, options, () => {
    handpose.detectStart(video, (results) => { hands = results; });
  });
}

function draw() {
  // --- SOLUZIONE ERRORE 2: IL PUNTINO CHE LASCIA LA SCIA ---
  // Ridisegnando lo sfondo a ogni frame, "puliamo" i puntini del frame precedente
  if (imgSfondo) {
    // --- SOLUZIONE ERRORE 1: LO SFONDO SDOPPIATO ---
    // Usiamo le coordinate (0,0) e forziamo le dimensioni a quelle della finestra
    imageMode(CORNER); 
    image(imgSfondo, 0, 0, width, height);
  } else {
    background(50); 
  }
  
  gestisciInputMano();
  gestisciPulsanteUscita();

  if (vittoria) {
    disegnaVittoria();
    return;
  }

  // Layout 3 sopra e 3 sotto
  for (let i = 0; i < coni.length; i++) {
    let riga = Math.floor(i / 3); 
    let colonna = i % 3;
    let x = (width / 4) * (colonna + 1);
    let y = (riga === 0) ? height * 0.40 : height * 0.85;
    disegnaCono(i, x, y);
  }

  if (selezione.attiva) {
    imageMode(CENTER);
    image(imgsGelato[selezione.gusto], cursor.x, cursor.y, 100, 100);
  }

  // Disegniamo il cursore DOPO lo sfondo così è sempre sopra a tutto
  disegnaCursore();
  
  ultimoPinch = pinchState;
  controllaVittoria();
}

// --- FUNZIONI DI SUPPORTO ---

function gestisciInputMano() {
  if (hands.length > 0) {
    let index = hands[0].keypoints[8];
    let thumb = hands[0].keypoints[4];
    // flipHorizontal è attivo nel setup, quindi mappiamo correttamente
    cursor.x = map(index.x, 0, video.width, 0, width);
    cursor.y = map(index.y, 0, video.height, 0, height);
    let d = dist(index.x, index.y, thumb.x, thumb.y);
    pinchState = d < 40;
  }
}

function disegnaCursore() {
  if (hands.length > 0) {
    push(); // Isola gli stili del cursore
    fill(pinchState ? "yellow" : "white");
    noStroke();
    ellipse(cursor.x, cursor.y, 15, 15);
    noFill();
    stroke(pinchState ? "yellow" : "white");
    strokeWeight(2);
    ellipse(cursor.x, cursor.y, 30, 30);
    pop();
  }
}

// (Le altre funzioni gestisciAzione, disegnaCono, ecc. rimangono uguali a prima)

// --- FUNZIONI DI DISEGNO E LOGICA ---

function disegnaCono(index, x, y) {
  imageMode(CENTER);
  
  // Ombra o evidenziazione se il cursore è vicino
  let areaClick = 100;
  if (dist(cursor.x, cursor.y, x, y - 80) < areaClick) {
    noFill();
    stroke(255, 255, 0); // Giallo evidenziatore
    strokeWeight(5);
    rectMode(CENTER);
    rect(x, y - 100, 140, 300, 20);
    
    // SELEZIONE AL PINCH
    if (pinchState && !ultimoPinch) {
      gestisciAzione(index);
    }
  }

  // Disegna Cono Base
  image(imgCono, x, y, 100, 180);
  
  // Disegna Palline
  for (let j = 0; j < coni[index].length; j++) {
    let gusto = coni[index][j];
    let pallinaY = (y - 80) - (j * 55); 
    image(imgsGelato[gusto], x, pallinaY, 90, 90);
  }
}

function gestisciPulsanteUscita() {
  let btnX = width - 60;
  let btnY = 60;
  let btnSize = 60;
  
  // Disegna bottone
  fill(200, 0, 0);
  stroke(255);
  strokeWeight(3);
  ellipse(btnX, btnY, btnSize, btnSize);
  
  // Disegna la X
  stroke(255);
  strokeWeight(5);
  line(btnX - 15, btnY - 15, btnX + 15, btnY + 15);
  line(btnX + 15, btnY - 15, btnX - 15, btnY + 15);
  
  // Interazione
  if (dist(cursor.x, cursor.y, btnX, btnY) < btnSize / 2) {
    if (pinchState && !ultimoPinch) {
      console.log("USCITA DAL GIOCO");
      // QUI INSERISCI IL CODICE PER TORNARE ALLA MAPPA
      // Esempio: statoGioco = "MAPPA";
      // Oppure ricarica la pagina:
      location.reload(); 
    }
  }
}

function gestisciAzione(index) {
  // Stessa logica di prima: Prendi o Posa
  if (!selezione.attiva) {
    if (coni[index].length > 0) {
      selezione.gusto = coni[index].pop();
      selezione.indiceCono = index;
      selezione.attiva = true;
    }
  } else {
    let conoTarget = coni[index];
    let pieno = conoTarget.length >= 4;
    let vuoto = conoTarget.length === 0;
    let stessoColore = !vuoto && conoTarget[conoTarget.length - 1] === selezione.gusto;
    
    if (!pieno && (vuoto || stessoColore)) {
      conoTarget.push(selezione.gusto);
      selezione.attiva = false;
      selezione.gusto = null;
    } else {
       // Errore: Rimetti a posto se clicchi sullo stesso
       if (index === selezione.indiceCono) {
         coni[index].push(selezione.gusto);
         selezione.attiva = false;
         selezione.gusto = null;
       }
    }
  }
}

function controllaVittoria() {
  let completati = 0;
  for (let c of coni) {
    if (c.length === 0) completati++;
    else if (c.length === 4 && c.every(v => v === c[0])) completati++;
  }
  if (completati === coni.length) vittoria = true;
}

function disegnaVittoria() {
  fill(0, 0, 0, 200);
  rect(width/2, height/2, width, height);
  fill(0, 255, 0);
  textSize(80);
  textAlign(CENTER, CENTER);
  text("BRAVISSIMO!", width/2, height/2);
  textSize(40);
  fill(255);
  text("Pinch sulla X per uscire", width/2, height/2 + 100);
}

// --- INPUT (uguale a prima) ---
function gestisciInputMano() {
  if (hands.length > 0) {
    let index = hands[0].keypoints[8];
    let thumb = hands[0].keypoints[4];
    cursor.x = map(index.x, 0, video.width, 0, width);
    cursor.y = map(index.y, 0, video.height, 0, height);
    let d = dist(index.x, index.y, thumb.x, thumb.y);
    pinchState = d < 40;
  }
}

function disegnaCursore() {
  if (hands.length > 0) {
    fill(pinchState ? "yellow" : "white");
    noStroke();
    circle(cursor.x, cursor.y, 20);
    noFill();
    stroke(pinchState ? "yellow" : "white");
    strokeWeight(2);
    circle(cursor.x, cursor.y, 50);
  }
}