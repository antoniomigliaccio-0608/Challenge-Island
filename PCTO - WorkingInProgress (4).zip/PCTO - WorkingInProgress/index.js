// --- STATO DEL GIOCO ---
let statoGioco = "MAPPA"; 
let video;
let handpose;
let hands = [];
let cursor;
let ultimoPinch = false;

// --- ASSET ---
let mappaImg, collisionImg, imgSfondoMinigioco, imgBuono;
let imgsCattivo = [];
let animDestra = [], animSinistra = [];
let imgnoko, kNoko, npcImg1, kDogghino;
let imgFrieren, kFrieren;

// --- GIOCATORE & NPC ---
let pg = { x: 2400, y: 2000, v: 3, dir: 'destra', frame: 0 };
let playerMinigioco = { x: 0, y: 0, size: 160 };

// COORDINATE NPC
let npcDog = { x: 1980, y: 4470 };    // Dogghino
let npcNoko = { x: 2400, y: 320 };    // Nokotan
let npcFrieren = { x: 4585, y: 3415 }; // Frieren

let npcAttivo = null;
let dialogoAttivo = false;

// --- LOGICA MINIGIOCO ---
let items = [];
let score = 0, lives = 3, gameOver = false;
let spawnTimer = 0;

function preload() {
  mappaImg = loadImage('mappa.png'); 
  collisionImg = loadImage('bordi.png'); 
  
  // Asset Nokotan
  imgnoko = loadImage('nokotan.png');
  kNoko = loadImage('DIVA.png');
  
  // Asset Dogghino
  npcImg1 = loadImage('dogghinopixel.png');
  kDogghino = loadImage('dogghinoDefinitivoimmagine1.png');

  // Asset Frieren
  imgFrieren = loadImage('frieren.png'); 
  kFrieren = loadImage('BADDIE.png');
  
  // Asset Minigioco
  imgSfondoMinigioco = loadImage('immagini/sfondoScuola.jpg');
  imgBuono = loadImage('immagini/buono.png');
  imgsCattivo = [loadImage('immagini/cattivo1.png'), loadImage('immagini/cattivo2.png')];

  // Yoshi Animazioni
  for (let i = 1; i <= 4; i++) {
    animDestra.push(loadImage(`destra${i}.png`));
    animSinistra.push(loadImage(`sinistra${i}.png`));
  }
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  playerMinigioco.x = width / 2;
  playerMinigioco.y = height - 200;

  let options = { maxHands: 1, runtime: 'mediapipe', flipHorizontal: true };
  handpose = ml5.handPose(video, options, () => {
    handpose.detectStart(video, (results) => { hands = results; });
  });
}

function draw() {
  background(0);
  aggiornaInputMano();

  if (statoGioco === "MAPPA") {
    disegnaEsplorazione();
  } else if (statoGioco === "DIALOGO_NOKO") {
    disegnaEsplorazione(); 
    disegnaMenuScelta();
  } else if (statoGioco === "MINIGIOCO") {
    eseguiMinigioco();
  }
  
  disegnaCursore();
}

function aggiornaInputMano() {
  if (hands.length > 0) {
    let index = hands[0].keypoints[8];
    let thumb = hands[0].keypoints[4];
    cursor = {
      x: map(index.x, 0, video.width, 0, width),
      y: map(index.y, 0, video.height, 0, height)
    };
    let d = dist(index.x, index.y, thumb.x, thumb.y);
    let pinchOra = d < 40;
    if (pinchOra && !ultimoPinch) gestisciPinch();
    ultimoPinch = pinchOra;
  }
}

function gestisciPinch() {
  if (dialogoAttivo) {
    dialogoAttivo = false;
    npcAttivo = null;
    return; 
  }

  if (statoGioco === "MAPPA") {
    // Check Nokotan (Attiva scelta minigioco)
    if (dist(pg.x, pg.y, npcNoko.x, npcNoko.y) < 200) {
      statoGioco = "DIALOGO_NOKO";
    } 
    // Check Dogghino (Solo dialogo)
    else if (dist(pg.x, pg.y, npcDog.x, npcDog.y) < 200) {
      dialogoAttivo = true;
      npcAttivo = { img: kDogghino, testo: "Bau! Sono Dogghino! Benvenuto nella mappa." };
    }
    // Check Frieren (Solo dialogo)
    else if (dist(pg.x, pg.y, npcFrieren.x, npcFrieren.y) < 200) {
      dialogoAttivo = true;
      npcAttivo = { img: kFrieren, testo: "Yoshi... hai visto dei demoni?" };
    }
  } else if (statoGioco === "DIALOGO_NOKO") {
    if (cursor.x < width/2) { 
        resetMinigioco(); 
        statoGioco = "MINIGIOCO"; 
    } else { 
        statoGioco = "MAPPA"; 
        dialogoAttivo = true; 
        npcAttivo = { img: kNoko, testo: "NUN! Maleducato!" };
    }
  } else if (gameOver) {
    resetMinigioco();
    statoGioco = "MAPPA";
  }
}

function disegnaEsplorazione() {
  let camX = constrain(width/2 - pg.x, -(mappaImg.width - width), 0);
  let camY = constrain(height/2 - pg.y, -(mappaImg.height - height), 0);

  if (cursor && !dialogoAttivo) {
    let nx = pg.x, ny = pg.y;
    if (cursor.x > width/2 + 50) { nx += pg.v; pg.dir = 'destra'; }
    if (cursor.x < width/2 - 50) { nx -= pg.v; pg.dir = 'sinistra'; }
    if (cursor.y < height/2 - 50) ny -= pg.v;
    if (cursor.y > height/2 + 50) ny += pg.v;

    if (red(collisionImg.get(nx, ny)) > 128) {
      pg.x = nx; pg.y = ny;
      if (frameCount % 10 === 0) pg.frame = (pg.frame + 1) % 4;
    }
  }

  push();
  translate(camX, camY);
  image(mappaImg, 0, 0);
  
  // Render NPC
  image(imgnoko, npcNoko.x, npcNoko.y, 150, 90);
  image(npcImg1, npcDog.x, npcDog.y, 200, 200);
  image(imgFrieren, npcFrieren.x, npcFrieren.y, 80, 110);
  
  let imgY = (pg.dir === 'destra') ? animDestra[pg.frame] : animSinistra[pg.frame];
  image(imgY, pg.x - 60, pg.y - 60, 120, 120);
  pop();

  if (dialogoAttivo && npcAttivo) {
     fill(0, 180); rect(50, height-150, width-100, 100, 15);
     image(npcAttivo.img, 50, height-250, 150, 150);
     fill(255); textSize(20); text(npcAttivo.testo, 220, height-90);
  }
}

function eseguiMinigioco() {
  if (gameOver) {
    background(0); fill(255); textAlign(CENTER); text("GAME OVER - PINCH PER TORNARE", width/2, height/2);
    return;
  }
  image(imgSfondoMinigioco, 0, 0, width, height);
  playerMinigioco.x = lerp(playerMinigioco.x, cursor.x - 80, 0.2);
  let imgP = (pg.dir === 'destra') ? animDestra[pg.frame] : animSinistra[pg.frame];
  image(imgP, playerMinigioco.x, playerMinigioco.y, 160, 160);

  spawnTimer++;
  if (spawnTimer > 60) {
    let isG = random() > 0.4;
    items.push({ x: random(50, width-50), y: -50, type: isG ? 'g' : 'b', img: isG ? imgBuono : random(imgsCattivo) });
    spawnTimer = 0;
  }
  for (let i = items.length-1; i >= 0; i--) {
    items[i].y += 5;
    image(items[i].img, items[i].x, items[i].y, 70, 70);
    if (dist(items[i].x + 35, items[i].y + 35, playerMinigioco.x + 80, playerMinigioco.y + 80) < 60) {
      if (items[i].type === 'g') score += 10; else lives--;
      items.splice(i, 1);
      if (lives <= 0) gameOver = true;
    }
  }
  fill(255); textSize(24); text("Punti: " + score + " Vite: " + lives, 30, 40);
}

function disegnaMenuScelta() {
  fill(0, 150); rect(0, 0, width, height);
  fill(255); textAlign(CENTER); text("VUOI GIOCARE? PINCH A SINISTRA PER SÌ, DESTRA PER NO", width/2, height/2);
}

function resetMinigioco() { score = 0; lives = 3; items = []; gameOver = false; }

function disegnaCursore() {
  if (cursor) { fill(ultimoPinch ? "lime" : "red"); ellipse(cursor.x, cursor.y, 20, 20); }
}