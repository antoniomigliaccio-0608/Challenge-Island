// --- VARIABILI YOSHI & MAPPA ---
let mappaImg, collisionImg;
let pg = { x: 2400, y: 2000, v: 4 }; 
let dx1, dx2, dx3, dx4, sx1, sx2, sx3, sx4, yoshiFermo;

let sceltaSelezionata = "SÌ"; // Di default su SÌ
let mostraRisposta = false;   // Per mostrare la reazione dell'NPC dopo la scelta
let testoRisposta = "";      // Il testo della reazione

// dogghino
let npc = { x: 1980, y: 4470 };
let npcImg;
let kDogghino;


//frieren
let npc2 = { x: 4585, y: 3415}
let imgfrieren;
let kFrieren;

//nokotan
let npc3 = { x: 2480, y: 395}
let imgnoko;
let kNoko;


//distanza npc
let distanzaNPC = 200;
let calc;

let dialogoAttivo = false;
let ultimoClickStato = false;

// --- VARIABILI HAND TRACKING ---
let cam, handpose, hands = [];
let cursor;
let TRACKED_KEYPOINT_INDEX = 8; // Punta dell'indice
let THUMB_KEYPOINT_INDEX = 4;   // Punta del pollice
let clicked = false;
let npcAttivo = null; // Memorizzerà l'oggetto dell'NPC vicino

function preload() {
  mappaImg = loadImage('mappa.png'); 
  collisionImg = loadImage('bordi.png'); 
  
  // Sprite Destra
  dx1 = loadImage('yoshisinistro1destra.png');
  dx2 = loadImage('yoshisinistro2destra.png');
  dx3 = loadImage('yoshidestro1destra.png');
  dx4 = loadImage('yoshidestro2destra.png');
  
  // Sprite Sinistra
  sx1 = loadImage('yoshisinistro1sinistra.png');
  sx2 = loadImage('yoshisinistro2sinistra.png');
  sx3 = loadImage('yoshidestro1sinistra.png');
  sx4 = loadImage('yoshidestro2sinistra.png');

  npcImg = loadImage('dogghinopixel.png');
  kDogghino = loadImage('dogghinoDefinitivoimmagine1.png')

  imgfrieren = loadImage('frieren.png')
  kFrieren = loadImage('BADDIE.png')

  imgnoko = loadImage('nokotan.png');
  kNoko = loadImage('DIVA.png')
  
  yoshiFermo = dx1;
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  noSmooth();
  
  cam = createPhoneCamera('environment', false, 'fitHeight');
  enableCameraTap();
  
  cam.onReady(() => {
    let options = { maxHands: 1, runtime: 'mediapipe', flipHorizontal: true };
    handpose = ml5.handPose(options, () => {
      console.log("Tracking attivo!");
      handpose.detectStart(cam.videoElement, (results) => { 
        hands = results; 
      });
    });
  });
}

function draw() {
  background(0);

  let nuovaX = pg.x;
  let nuovaY = pg.y;
  let inMovimento = false;
  let immagineDaMostrare = yoshiFermo;

  if (hands.length > 0) {
    let hand = hands[0];
    let indexPt = hand.keypoints[TRACKED_KEYPOINT_INDEX];
    let thumbPt = hand.keypoints[THUMB_KEYPOINT_INDEX];
    
    cursor = cam.mapKeypoint(indexPt);
    let thumbCursor = cam.mapKeypoint(thumbPt);

// --- LOGICA PINCH (TOGGLE) ---
    let d = dist(cursor.x, cursor.y, thumbCursor.x, thumbCursor.y);
    let pinchOra = (d < 45); 

    if (pinchOra && !ultimoClickStato) {
      // Controlliamo chi è vicino
      if (dist(pg.x, pg.y, npc.x, npc.y) < distanzaNPC) {
        npcAttivo = { img: kDogghino, testo: "Sono Dogghino Arrabbiato!", x: npc.x, y: npc.y };
        dialogoAttivo = !dialogoAttivo;
      } 
      else if (dist(pg.x, pg.y, npc2.x, npc2.y - 30) < distanzaNPC) {
        npcAttivo = { img: kFrieren, testo: "BUONGIORNO YOSHI", x: npc2.x, y: npc2.y };
        dialogoAttivo = !dialogoAttivo;
      }
      else if (dist(pg.x, pg.y, npc3.x, npc3.y) < distanzaNPC) {
        npcAttivo = { img: kNoko, testo: "Hai dei cracker per cervi? nut", x: npc3.x, y: npc3.y };
        dialogoAttivo = !dialogoAttivo;
      }
    }
    ultimoClickStato = pinchOra;

    // --- LOGICA MOVIMENTO ---
    let soglia = 60; 
    let centroX = width / 2;
    let centroY = height / 2;
    let frameAnim = floor(frameCount / 8) % 4;

    if (cursor.x > centroX + soglia) {
      nuovaX += pg.v;
      inMovimento = true;
      immagineDaMostrare = [sx1, sx2, sx3, sx4][frameAnim];
      yoshiFermo = sx1;
    } else if (cursor.x < centroX - soglia) {
      nuovaX -= pg.v;
      inMovimento = true;
      immagineDaMostrare = [dx1, dx2, dx3, dx4][frameAnim];
      yoshiFermo = dx1;
    }

    if (cursor.y < centroY - soglia) {
      nuovaY -= pg.v;
      inMovimento = true;
    } else if (cursor.y > centroY + soglia) {
      nuovaY += pg.v;
      inMovimento = true;
    }

    if (inMovimento && (immagineDaMostrare === yoshiFermo)) {
       immagineDaMostrare = (yoshiFermo === sx1) ? 
         [sx1, sx2, sx3, sx4][frameAnim] : 
         [dx1, dx2, dx3, dx4][frameAnim];
    }
  }

  if (!inMovimento) immagineDaMostrare = yoshiFermo;

  // --- COLLISIONI ---
  let colorePixel = collisionImg.get(nuovaX, nuovaY);
  if (red(colorePixel) > 128) {
    pg.x = nuovaX;
    pg.y = nuovaY;
  }

  // --- CAMERA ---
  let camX = width / 2 - pg.x;
  let camY = height / 2 - pg.y;
  camX = constrain(camX, -(mappaImg.width - width), 0);
  camY = constrain(camY, -(mappaImg.height - height), 0);

  push();
  translate(camX, camY);
  image(mappaImg, 0, 0);
  imageMode(CENTER);

  // 2. DISEGNA IL DOGGHINO (NPC) qui!
  image(npcImg, npc.x, npc.y, 200, 200);

  image(imgfrieren,npc2.x,npc2.y,70,70);

  image(imgnoko,npc3.x,npc3.y,150,90);

  image(immagineDaMostrare, pg.x, pg.y, 200, 200);

  pop();

  calc = dist(pg.x,pg.y,npc.x,npc.y);

// --- VISUALIZZAZIONE NPC ---
  if (dialogoAttivo && npcAttivo) {
    // Chiudi se ti allontani dall'NPC specifico
    if (dist(pg.x, pg.y, npcAttivo.x, npcAttivo.y) > distanzaNPC + 50) {
      dialogoAttivo = false;
      npcAttivo = null;
    } else {
      push();
      imageMode(CORNER);
      let h = height * 0.7; 
      let proporzione = npcAttivo.img.width / npcAttivo.img.height;
      let w = h * proporzione;

      image(npcAttivo.img, 20, height - h - 20, w, h);
      
      fill(0, 0, 0, 180);
      noStroke();
      rect(w + 10, height - 160, width - w - 40, 120, 15);
      
      fill(255);
      textSize(22);
      textAlign(LEFT, CENTER);
      text(npcAttivo.testo, w + 40, height - 100);
      pop();
    }
  }

  drawUI();
}

function drawUI() {
  if (cursor) {
    // Il puntino diventa verde quando clicchi, ma senza testo
    if (clicked) {
      fill(0, 255, 0); 
      stroke(255);
      strokeWeight(3);
    } else {
      fill(255, 0, 0, 200); 
      noStroke();
    }
    ellipse(cursor.x, cursor.y, 30, 30);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}