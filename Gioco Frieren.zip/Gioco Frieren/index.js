let video;
let handpose;
let hands = [];
let grabbedItem = null;
let items = [];
let score = 0;
let errors = 0;
const maxErrors = 3;
const goal = 10;
let gameOver = false;
let gameWon = false;

let imgSfondo, imgPergamena;
let imgPozioni = [];
let targetPotionImg; 
let targetPotionIndex; 

let lerpPos; 
const smoothness = 0.15;
let targetZone;
let wasPinching = false;

let debugMsg = "Avvio...";

function preload() {
  imgSfondo = loadImage('Frieren.png'); 
  imgPergamena = loadImage('magia/pergamena.png'); 
  for (let i = 1; i <= 5; i++) {
    imgPozioni.push(loadImage(`magia/pozione${i}.png`));
  }
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  video = createCapture(VIDEO, () => {
    debugMsg = "📷 Camera OK - carico modello...";
    
    // detectStart DENTRO la callback della camera, solo quando è pronta
    handpose = ml5.handPose(video, () => {
      debugMsg = "✅ Modello pronto!";
      handpose.detectStart(video, (results) => {
        hands = results;
        if (results.length > 0) {
          let hand = results[0];
          let kps = hand.keypoints || hand.landmarks;
          if (kps) {
            debugMsg = `✋ Mano! keypoints: ${kps.length}`;
          }
        } else {
          debugMsg = "👁️ Attivo - mostra la mano";
        }
      });
    });
  });

  video.size(640, 480);
  video.hide(); 

  lerpPos = createVector(width / 2, height / 2);
  prossimaRicetta();
  targetZone = { 
    x: width * 0.38, 
    y: height - 160, 
    w: width * 0.24, 
    h: 110 
  };
}

function prossimaRicetta() {
  targetPotionIndex = floor(random(0, imgPozioni.length));
  targetPotionImg = imgPozioni[targetPotionIndex];
}

function draw() {
  if (imgSfondo) image(imgSfondo, 0, 0, width, height);

  if (!gameOver && !gameWon) {
    playGame();
  } else {
    showEndScreen();
  }
}

function playGame() {
  let isPinching = false;

  if (hands.length > 0) {
    let hand = hands[0];

    // Supporta sia keypoints (ml5@1) che landmarks (ml5@0.x)
    let kps = hand.keypoints || hand.landmarks;

    if (kps && kps.length >= 10) {
      let index = kps[8]; 
      let thumb = kps[4]; 
      let palm  = kps[9];  

      // keypoints hanno .x/.y, landmarks hanno [0],[1],[2]
      let ix = index.x !== undefined ? index.x : index[0];
      let iy = index.y !== undefined ? index.y : index[1];
      let tx2 = thumb.x !== undefined ? thumb.x : thumb[0];
      let ty2 = thumb.y !== undefined ? thumb.y : thumb[1];
      let px = palm.x  !== undefined ? palm.x  : palm[0];
      let py = palm.y  !== undefined ? palm.y  : palm[1];

      let tx = map(px, 0, video.width, width, 0);
      let ty = map(py, 0, video.height, 0, height);
      lerpPos.x = lerp(lerpPos.x, tx, smoothness);
      lerpPos.y = lerp(lerpPos.y, ty, smoothness);

      let pinchDist = dist(ix, iy, tx2, ty2);
      isPinching = pinchDist < 35;

      debugMsg = `✋ pinch dist: ${nf(pinchDist,1,1)} | pinching: ${isPinching}`;
    }
  }

  // Aggiorna posizione oggetto grabbed OGNI FRAME
  if (grabbedItem) {
    grabbedItem.x = lerpPos.x - 35;
    grabbedItem.y = lerpPos.y - 35;
  }

  // PINCH INIZIA: prendi oggetto (solo sulla transizione OFF→ON)
  if (isPinching && !wasPinching) {
    for (let i = items.length - 1; i >= 0; i--) {
      if (dist(lerpPos.x, lerpPos.y, items[i].x + 35, items[i].y + 35) < 60) {
        grabbedItem = items[i];
        break;
      }
    }
  }

  // PINCH FINISCE: rilascia oggetto (solo sulla transizione ON→OFF)
  if (!isPinching && wasPinching && grabbedItem) {
    checkDrop(grabbedItem);
    grabbedItem = null;
  }

  wasPinching = isPinching;

  drawCursor(isPinching);
  updateAndDrawItems();
  disegnaInterfaccia();
}

function drawCursor(isPinching) {
  push();
  translate(lerpPos.x, lerpPos.y);

  if (isPinching) {
    drawingContext.shadowBlur = 20;
    drawingContext.shadowColor = 'rgba(255, 80, 80, 0.8)';
    fill(220, 50, 50, 200);
    stroke(255, 150, 150);
    strokeWeight(2);
    circle(0, 0, 36);
    stroke(255);
    strokeWeight(2.5);
    noFill();
    line(-6, -6, 6, 6);
    line(6, -6, -6, 6);
  } else {
    drawingContext.shadowBlur = 15;
    drawingContext.shadowColor = 'rgba(100, 255, 180, 0.7)';
    noFill();
    stroke(100, 255, 180, 180);
    strokeWeight(1.5);
    drawDashedCircle(0, 0, 28, 8);
    fill(100, 255, 180, 220);
    noStroke();
    circle(0, 0, 7);
    stroke(100, 255, 180, 200);
    strokeWeight(1.5);
    line(-18, 0, -8, 0);
    line(8,   0, 18, 0);
    line(0, -18, 0, -8);
    line(0,   8, 0,  18);
  }

  drawingContext.shadowBlur = 0;
  pop();
}

function drawDashedCircle(cx, cy, r, dashCount) {
  let angleStep = TWO_PI / dashCount;
  for (let i = 0; i < dashCount; i++) {
    if (i % 2 === 0) {
      let a1 = i * angleStep;
      let a2 = a1 + angleStep * 0.65;
      beginShape();
      noFill();
      for (let j = 0; j <= 10; j++) {
        let a = lerp(a1, a2, j / 10);
        vertex(cx + cos(a) * r, cy + sin(a) * r);
      }
      endShape();
    }
  }
}

function checkDrop(item) {
  if (item.x + 35 > targetZone.x && item.x + 35 < targetZone.x + targetZone.w &&
      item.y + 35 > targetZone.y && item.y + 35 < targetZone.y + targetZone.h) {
    
    if (item.id === targetPotionIndex) {
      score++;
      if (score >= goal) gameWon = true;
      else prossimaRicetta();
    } else {
      errors++;
      if (errors >= maxErrors) gameOver = true;
    }
    items.splice(items.indexOf(item), 1);
  }
}

function updateAndDrawItems() {
  if (frameCount % 80 === 0 && items.length < 6) {
    
    // Controlla quali tipi mancano tra gli items presenti
    let tipiPresenti = items.map(i => i.id);
    let tipiMancanti = [];
    for (let t = 0; t < imgPozioni.length; t++) {
      if (!tipiPresenti.includes(t)) tipiMancanti.push(t);
    }

    // Se mancano tipi, spawna uno di quelli mancanti, altrimenti random
    let rIdx;
    if (tipiMancanti.length > 0) {
      rIdx = random(tipiMancanti);
    } else {
      rIdx = floor(random(0, imgPozioni.length));
    }

    items.push({
      x: random(width * 0.35, width * 0.6), 
      y: random(height * 0.2, height * 0.55), 
      img: imgPozioni[rIdx],
      id: rIdx
    });
  }

  for (let item of items) {
    image(item.img, item.x, item.y, 70, 70);
  }
}

function disegnaInterfaccia() {
  push();
  imageMode(CORNER);
  image(imgPergamena, 1, 0, 280, 350); 

  fill(50, 20, 0); 
  textAlign(CENTER);
  textFont('Georgia');
  textStyle(BOLD);
  textSize(18);
  text("ORDINE\nALCHEMICO", 136, 60);
  textStyle(NORMAL);
  textSize(14);
  text("Cerca questa:", 140, 120);
  imageMode(CENTER);
  image(targetPotionImg, 138, 185, 80, 80);
  textAlign(LEFT);
  textSize(15);
  text(`Giuste: ${score}/${goal}`, 100, 260);
  text(`Errori: ${errors}/${maxErrors}`, 100, 300);
  pop();
}

function showEndScreen() {
  background(0, 200);
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(40);
  if (gameWon) text("VITTORIA!", width/2, height/2);
  else text("HAI PERSO!", width/2, height/2);
  textSize(20);
  text("Premi F5 per rigiocare", width/2, height/2 + 60);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  targetZone = { 
    x: width * 0.38, 
    y: height - 160, 
    w: width * 0.24, 
    h: 110 
  };
}