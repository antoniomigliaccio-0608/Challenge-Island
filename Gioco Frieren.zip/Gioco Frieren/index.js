let video;
let handpose;
let hands = [];
let grabbedItem = null;
let items = [];
let score = 0;
let errors = 0;
const maxErrors = 3;
const goal = 10;
let gameOver = false;
let gameWon = false;

let imgSfondo, imgPergamena;
let imgPozioni = [];
let targetPotionImg; 
let targetPotionIndex; 

let musicaFrieren;
let musicStarted = false;

let lerpPos; 
const smoothness = 0.15;
let targetZone;
let wasPinching = false;

function preload() {
  imgSfondo = loadImage('Frieren.png'); 
  imgPergamena = loadImage('magia/pergamena.png'); 
  for (let i = 1; i <= 5; i++) {
    imgPozioni.push(loadImage(`magia/pozione${i}.png`));
  }
  musicaFrieren = loadSound('GiocoFrieren.mp3');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  video = createCapture(VIDEO, () => {
    handpose = ml5.handPose(video, () => {
      console.log("Sistema Alchemico Pronto!");
      handpose.detectStart(video, (results) => {
        hands = results;
      });
    });
  });

  video.size(640, 480);
  video.hide(); 

  lerpPos = createVector(width / 2, height / 2);
  prossimaRicetta();
  
  targetZone = { 
    x: width * 0.38, 
    y: height - 160, 
    w: width * 0.24, 
    h: 110 
  };
}

function prossimaRicetta() {
  targetPotionIndex = floor(random(0, imgPozioni.length));
  targetPotionImg = imgPozioni[targetPotionIndex];
}

function draw() {
  if (imgSfondo) image(imgSfondo, 0, 0, width, height);

  // Gestione musica
  if (!musicStarted && hands.length > 0) {
    if (musicaFrieren && !musicaFrieren.isPlaying()) {
      musicaFrieren.loop();
      musicaFrieren.setVolume(0.4);
      musicStarted = true;
    }
  }

  if (!gameOver && !gameWon) {
    playGame();
  } else {
    showEndScreen();
    if (musicaFrieren && musicaFrieren.isPlaying()) musicaFrieren.stop();
  }
}

function playGame() {
  let isPinching = false;

  if (hands.length > 0) {
    let hand = hands[0];
    let kps = hand.keypoints;
    if (kps && kps.length >= 10) {
      let index = kps[8]; 
      let thumb = kps[4]; 
      let palm  = kps[9];  

      let tx = map(palm.x, 0, video.width, width, 0);
      let ty = map(palm.y, 0, video.height, 0, height);
      
      lerpPos.x = lerp(lerpPos.x, tx, smoothness);
      lerpPos.y = lerp(lerpPos.y, ty, smoothness);

      let pinchDist = dist(index.x, index.y, thumb.x, thumb.y);
      isPinching = pinchDist < 35;
    }
  }

  if (grabbedItem) {
    grabbedItem.x = lerpPos.x - 35;
    grabbedItem.y = lerpPos.y - 35;
  }

  if (isPinching && !wasPinching) {
    for (let i = items.length - 1; i >= 0; i--) {
      if (dist(lerpPos.x, lerpPos.y, items[i].x + 35, items[i].y + 35) < 60) {
        grabbedItem = items[i];
        break;
      }
    }
  }

  if (!isPinching && wasPinching && grabbedItem) {
    checkDrop(grabbedItem);
    grabbedItem = null;
  }

  wasPinching = isPinching;
  drawCursor(isPinching);
  updateAndDrawItems();
  disegnaInterfaccia();
}

function drawCursor(isPinching) {
  push();
  translate(lerpPos.x, lerpPos.y);
  if (isPinching) {
    fill(220, 50, 50, 200);
    circle(0, 0, 36);
  } else {
    fill(100, 255, 180, 220);
    circle(0, 0, 10);
    noFill();
    stroke(100, 255, 180);
    ellipse(0, 0, 30, 30);
  }
  pop();
}

function checkDrop(item) {
  if (item.x + 35 > targetZone.x && item.x + 35 < targetZone.x + targetZone.w &&
      item.y + 35 > targetZone.y && item.y + 35 < targetZone.y + targetZone.h) {
    
    if (item.id === targetPotionIndex) {
      score++;
      if (score >= goal) gameWon = true;
      else prossimaRicetta();
    } else {
      errors++;
      if (errors >= maxErrors) gameOver = true;
    }
    items.splice(items.indexOf(item), 1);
  }
}

// LOGICA SPAWN: Almeno una per tipo
function updateAndDrawItems() {
  if (frameCount % 80 === 0 && items.length < 8) { // Aumentato limite a 8 per gestire meglio i tipi
    let tipiPresenti = items.map(i => i.id);
    let tipiMancanti = [];

    // Controlla quali delle 5 pozioni non sono a schermo
    for (let i = 0; i < imgPozioni.length; i++) {
      if (!tipiPresenti.includes(i)) {
        tipiMancanti.push(i);
      }
    }

    let rIdx;
    if (tipiMancanti.length > 0) {
      // Se mancano tipi, spawnane uno a caso tra quelli mancanti
      rIdx = random(tipiMancanti);
    } else {
      // Se ci sono già tutti i tipi, spawnane uno a caso
      rIdx = floor(random(0, imgPozioni.length));
    }

    items.push({
      x: random(width * 0.35, width * 0.65), 
      y: random(height * 0.2, height * 0.55), 
      img: imgPozioni[rIdx],
      id: rIdx
    });
  }

  for (let item of items) {
    image(item.img, item.x, item.y, 70, 70);
  }
}

function disegnaInterfaccia() {
  push();
  imageMode(CORNER);
  image(imgPergamena, 1, 0, 280, 350); 
  fill(50, 20, 0); 
  textAlign(CENTER);
  textSize(18);
  text("ORDINE\nALCHEMICO", 136, 60);
  imageMode(CENTER);
  image(targetPotionImg, 138, 185, 80, 80);
  textSize(15);
  text(`Giuste: ${score}/${goal}`, 138, 260);
  text(`Errori: ${errors}/${maxErrors}`, 138, 300);
  pop();
}

function showEndScreen() {
  background(0, 200);
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(40);
  if (gameWon) text("VITTORIA!", width/2, height/2);
  else text("HAI PERSO!", width/2, height/2);
  textSize(20);
  text("Premi F5 per rigiocare", width/2, height/2 + 60);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  targetZone = { x: width * 0.38, y: height - 160, w: width * 0.24, h: 110 };
}