// --- VARIABILI YOSHI & MAPPA ---
let mappaImg, collisionImg;
let pg = { x: 2400, y: 2000, v: 5 };
let dx1, dx2, dx3, dx4, sx1, sx2, sx3, sx4, yoshiFermo;

// --- VARIABILI HANDPOSE ---
let cam, handpose, hands = [], cursor;
let TRACKED_KEYPOINT_INDEX = 8; // Punta dell'indice
let SHOW_VIDEO = false;

function preload() {
  // Caricamento Asset (Assicurati che i percorsi siano corretti)
  mappaImg = loadImage('mappa.png'); 
  collisionImg = loadImage('bordi.png'); 
  dx1 = loadImage('yoshisinistro1destra.png');
  dx2 = loadImage('yoshisinistro2destra.png');
  dx3 = loadImage('yoshidestro1destra.png');
  dx4 = loadImage('yoshidestro2destra.png');
  sx1 = loadImage('yoshisinistro1sinistra.png');
  sx2 = loadImage('yoshisinistro2sinistra.png');
  sx3 = loadImage('yoshidestro1sinistra.png');
  sx4 = loadImage('yoshidestro2sinistra.png');
  yoshiFermo = dx1;
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  noSmooth();
  
  // Setup Camera e ML5
  cam = createPhoneCamera('environment', false, 'fitHeight');
  enableCameraTap();
  
  cam.onReady(() => {
    let options = { maxHands: 1, runtime: 'mediapipe', flipHorizontal: true };
    handpose = ml5.handPose(options, () => {
      handpose.detectStart(cam.videoElement, (results) => { hands = results; });
    });
  });
}

function draw() {
  background(0);

  let nuovaX = pg.x;
  let nuovaY = pg.y;
  let inMovimento = false;
  let immagineDaMostrare = yoshiFermo;

  // --- LOGICA DI MOVIMENTO CON HAND TRACKING ---
  if (hands.length > 0) {
    let keypoint = hands[0].keypoints[TRACKED_KEYPOINT_INDEX];
    cursor = cam.mapKeypoint(keypoint);

    // Calcoliamo la direzione rispetto al centro dello schermo
    // Poiché Yoshi è sempre al centro (grazie alla camera), 
    // muoviamo pg.x/y se il cursore è lontano dal centro.
    let soglia = 50; 
    let centroX = width / 2;
    let centroY = height / 2;

    if (cursor.x > centroX + soglia) {
      nuovaX += pg.v;
      inMovimento = true;
      let indice = floor(frameCount / 10) % 4;
      immagineDaMostrare = [sx1, sx2, sx3, sx4][indice];
      yoshiFermo = sx1;
    } else if (cursor.x < centroX - soglia) {
      nuovaX -= pg.v;
      inMovimento = true;
      let indice = floor(frameCount / 10) % 4;
      immagineDaMostrare = [dx1, dx2, dx3, dx4][indice];
      yoshiFermo = dx1;
    }

    if (cursor.y < centroY - soglia) {
      nuovaY -= pg.v;
      inMovimento = true;
    } else if (cursor.y > centroY + soglia) {
      nuovaY += pg.v;
      inMovimento = true;
    }
  }

  if (!inMovimento) immagineDaMostrare = yoshiFermo;

  // --- COLLISIONI ---
  let colorePixel = collisionImg.get(nuovaX, nuovaY);
  if (red(colorePixel) > 128) {
    pg.x = nuovaX;
    pg.y = nuovaY;
  }

  // --- CAMERA ---
  let camX = width / 2 - pg.x;
  let camY = height / 2 - pg.y;
  camX = constrain(camX, -(mappaImg.width - width), 0);
  camY = constrain(camY, -(mappaImg.height - height), 0);

  push();
  translate(camX, camY);
  image(mappaImg, 0, 0);
  imageMode(CENTER);
  image(immagineDaMostrare, pg.x, pg.y, 200, 200);
  pop();

  // --- FEEDBACK VISIVO CURSORE ---
  if (cursor) {
    fill(255, 0, 0, 150);
    noStroke();
    ellipse(cursor.x, cursor.y, 20, 20);
  }
  
  drawUI();
}

function drawUI() {
  fill(255);
  textSize(16);
  text("Muovi l'indice per guidare Yoshi!", 20, 30);
  if (hands.length === 0) text("Mano non rilevata", 20, 55);
}

function touchStarted() { SHOW_VIDEO = !SHOW_VIDEO; return false; }