let video;
let handpose;
let hands = [];
let player;
let items = [];
let score = 0;
let lives = 3;
let gameState = 'menu';
let spawnTimer = 0;
let spawnInterval = 100;

let imgSfondo;
let imgBuono;
let imgsCattivo = [];
let animDestra = [];
let animSinistra = [];
let currentFrame = 0;

// Variabile per la musica
let musicaSfondo;

// Variabili pinch
let pinched = false;
let pinchX = 0;
let pinchY = 0;
let pinchJustPressed = false;
let prevPinched = false;

function preload() {
  // Caricamento Immagini
  imgSfondo = loadImage('immagini/sfondoScuola.jpg');
  imgBuono = loadImage('immagini/buono.png');
  imgsCattivo.push(loadImage('immagini/cattivo1.png'));
  imgsCattivo.push(loadImage('immagini/cattivo2.png'));
  for (let i = 1; i <= 4; i++) {
    animDestra.push(loadImage(`immagini/destra${i}.png`));
    animSinistra.push(loadImage(`immagini/sinistra${i}.png`));
  }
  
  // --- CARICAMENTO MUSICA ---
  // Assicurati che il file sia GiocoNokotan.mp3
  musicaSfondo = loadSound('GiocoNokotan.mp3');
}

function setup() {
  createCanvas(windowWidth, windowHeight);

  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  let options = {
    maxHands: 1,
    runtime: 'mediapipe',
    flipHorizontal: false
  };

  handpose = ml5.handPose(video, options, () => {
    console.log("Sistema AI pronto!");
    handpose.detectStart(video, (results) => {
      hands = results;
    });
  });

  player = {
    x: width / 2,
    y: height - 200,
    size: 160,
    direction: 'destra'
  };
}

function draw() {
  image(imgSfondo, 0, 0, width, height);

  updatePinch(); 

  if (gameState === 'playing') {
    updateGame();
    drawGame();
    drawLegend();
    drawCloseButton(); 
    checkCloseButtonPinch();
  } else if (gameState === 'menu') {
    drawGame();
    drawMenuOverlay();
    checkMenuPinch();
  } else if (gameState === 'paused') {
    drawGame();
    drawPauseOverlay();
    checkPausePinch();
  } else if (gameState === 'gameover') {
    showGameOver();
    checkGameOverPinch();
  }

  drawHandCursor();
}

// ─── LOGICA PINCH ────────────────────────────────────────────────────────────
function updatePinch() {
  prevPinched = pinched;
  if (hands && hands.length > 0) {
    let hand = hands[0];
    let index = hand.keypoints[8];
    let thumb = hand.keypoints[4];

    // Coordinate specchiate per la mano
    let ix = width - map(index.x, 0, video.width, 0, width);
    let iy = map(index.y, 0, video.height, 0, height);
    let tx = width - map(thumb.x, 0, video.width, 0, width);
    let ty = map(thumb.y, 0, video.height, 0, height);

    let d = dist(ix, iy, tx, ty);
    pinchX = (ix + tx) / 2;
    pinchY = (iy + ty) / 2;

    pinched = d < 40;
  } else {
    pinched = false;
  }
  pinchJustPressed = pinched && !prevPinched;
}

function drawHandCursor() {
  if (hands && hands.length > 0) {
    fill(255, 255, 255, pinched ? 200 : 120);
    stroke(255);
    strokeWeight(2);
    ellipse(pinchX, pinchY, pinched ? 20 : 30);
    noStroke();
  }
}

// ─── GESTIONE STATI E MUSICA ─────────────────────────────────────────────────
function startGame() {
  resetGame();
  gameState = 'playing';
  if (musicaSfondo && !musicaSfondo.isPlaying()) {
    musicaSfondo.loop();
    musicaSfondo.setVolume(0.4);
  }
}

function resetGame() {
  score = 0;
  lives = 3;
  items = [];
  spawnTimer = 0;
  player.x = width / 2;
  player.direction = 'destra';
}

function triggerGameOver() {
  gameState = 'gameover';
  if (musicaSfondo) musicaSfondo.stop(); 
}

// ─── GAME LOGIC ──────────────────────────────────────────────────────────────
function updateGame() {
  if (hands && hands.length > 0) {
    let finger = hands[0].keypoints[9]; // Centro del palmo
    let rawX = map(finger.x, 0, video.width, 0, width);
    let correctedX = width - rawX;

    let targetX = correctedX - player.size / 2;
    if (targetX > player.x + 2) player.direction = 'destra';
    else if (targetX < player.x - 2) player.direction = 'sinistra';

    player.x = lerp(player.x, targetX, 0.2);

    if (frameCount % 8 === 0) {
      currentFrame = (currentFrame + 1) % 4;
    }
  }

  spawnTimer++;
  if (spawnTimer >= spawnInterval) {
    spawnItem();
    spawnTimer = 0;
  }

  for (let i = items.length - 1; i >= 0; i--) {
    items[i].y += items[i].speed;
    let itemSize = 80;
    if (
      items[i].x < player.x + player.size * 0.75 &&
      items[i].x + itemSize > player.x + player.size * 0.25 &&
      items[i].y < player.y + player.size * 0.85 &&
      items[i].y + itemSize > player.y + player.size * 0.15
    ) {
      if (items[i].type === 'good') score += 10;
      else {
        lives--;
        if (lives <= 0) triggerGameOver();
      }
      items.splice(i, 1);
      continue;
    }
    if (items[i].y > height) items.splice(i, 1);
  }
}

function drawGame() {
  if (gameState === 'playing' || gameState === 'paused') {
    let imgToShow = (player.direction === 'destra') ? animDestra[currentFrame] : animSinistra[currentFrame];
    image(imgToShow, player.x, player.y, player.size, player.size);
  }

  for (let item of items) {
    image(item.img, item.x, item.y, 80, 80);
  }

  if (gameState === 'playing') {
    fill(0, 0, 0, 150);
    noStroke();
    rect(10, height - 75, 120, 65, 5);
    fill(255);
    textSize(22);
    textAlign(LEFT);
    textStyle(NORMAL);
    text("Punti: " + score, 20, height - 50);
    text("Vite: " + lives, 20, height - 20);
  }
}

// ─── UI & BOTTONI ────────────────────────────────────────────────────────────
function getCloseButtonBounds() {
  return { x: width - 60, y: 15, w: 44, h: 44 };
}

function drawCloseButton() {
  let b = getCloseButtonBounds();
  let hovering = pinchX > b.x && pinchX < b.x + b.w && pinchY > b.y && pinchY < b.y + b.h;
  fill(hovering ? color(220, 60, 60) : color(180, 40, 40, 200));
  rect(b.x, b.y, b.w, b.h, 8);
  fill(255);
  textAlign(CENTER, CENTER);
  text("✕", b.x + b.w / 2, b.y + b.h / 2);
}

function checkCloseButtonPinch() {
  if (pinchJustPressed) {
    let b = getCloseButtonBounds();
    if (pinchX > b.x && pinchX < b.x + b.w && pinchY > b.y && pinchY < b.y + b.h) {
      gameState = 'paused';
      if (musicaSfondo) musicaSfondo.pause();
    }
  }
}

function drawMenuOverlay() {
  fill(0, 0, 0, 175);
  rect(0, 0, width, height);
  let panW = min(560, width - 60);
  let panH = 580;
  let panX = width / 2 - panW / 2;
  let panY = height / 2 - panH / 2;
  fill(15, 15, 25, 220);
  rect(panX, panY, panW, panH, 16);
  
  fill(255, 230, 80);
  textAlign(CENTER, CENTER);
  textSize(38);
  text("🎒 ACCHIAPPA IL BISCOTTO!", width / 2, panY + 58);

  let btnW = 240, btnH = 56;
  let btnX = width / 2 - btnW / 2;
  let btnY = panY + 470;
  let hovering = pinchX > btnX && pinchX < btnX + btnW && pinchY > btnY && pinchY < btnY + btnH;
  fill(hovering ? color(255, 230, 50) : color(255, 200, 0));
  rect(btnX, btnY, btnW, btnH, 12);
  fill(20);
  textSize(22);
  text("▶   INIZIA", width / 2, btnY + btnH / 2);
}

function checkMenuPinch() {
  if (!pinchJustPressed) return;
  let panY = height / 2 - 580 / 2;
  let btnX = width / 2 - 120;
  let btnY = panY + 470;
  if (pinchX > btnX && pinchX < btnX + 240 && pinchY > btnY && pinchY < btnY + 56) {
    startGame();
  }
}

function drawPauseOverlay() {
  fill(0, 0, 0, 160);
  rect(0, 0, width, height);
  let panX = width / 2 - 190;
  let panY = height / 2 - 140;
  fill(15, 15, 25, 225);
  rect(panX, panY, 380, 280, 16);

  fill(255, 230, 80);
  textSize(40);
  text("⏸ PAUSA", width / 2, panY + 65);

  let btn1Y = panY + 150;
  let hover1 = pinchX > width/2-120 && pinchX < width/2+120 && pinchY > btn1Y && pinchY < btn1Y + 50;
  fill(hover1 ? color(255, 220, 30) : color(255, 200, 0));
  rect(width/2-120, btn1Y, 240, 50, 10);
  fill(20);
  text("▶   RIPRENDI", width/2, btn1Y + 25);
}

function checkPausePinch() {
  if (!pinchJustPressed) return;
  let btn1Y = (height / 2 - 140) + 150;
  if (pinchX > width/2-120 && pinchX < width/2+120 && pinchY > btn1Y && pinchY < btn1Y + 50) {
    gameState = 'playing';
    if (musicaSfondo) musicaSfondo.play();
  }
}

function showGameOver() {
  fill(0, 0, 0, 200);
  rect(0, 0, width, height);
  fill(255, 230, 80);
  textSize(60);
  text("GAME OVER", width / 2, height / 2 - 40);
  
  let btnY = height / 2 + 80;
  let hover = pinchX > width/2-130 && pinchX < width/2+130 && pinchY > btnY && pinchY < btnY + 56;
  fill(hover ? color(255, 220, 30) : color(255, 200, 0));
  rect(width/2-130, btnY, 260, 56, 10);
  fill(20);
  text("🔄   RIPROVA", width / 2, btnY + 28);
}

function checkGameOverPinch() {
  if (!pinchJustPressed) return;
  let btnY = height / 2 + 80;
  if (pinchX > width/2-130 && pinchX < width/2+130 && pinchY > btnY && pinchY < btnY + 56) {
    startGame();
  }
}

function spawnItem() {
  let isGood = random() > 0.4;
  let imgSelezionata = isGood ? imgBuono : random(imgsCattivo);
  items.push({
    x: random(80, width - 80),
    y: -90,
    speed: random(3, 6),
    type: isGood ? 'good' : 'bad',
    img: imgSelezionata
  });
}

function drawLegend() {
  push();
  fill(0, 0, 0, 160);
  rect(10, 10, 250, 100, 10);
  image(imgBuono, 20, 20, 35, 35);
  fill(255);
  textSize(16);
  textAlign(LEFT, CENTER);
  text("Prendi (Punti)", 70, 37);
  image(imgsCattivo[0], 20, 60, 35, 35);
  image(imgsCattivo[1], 60, 60, 35, 35);
  text("Evita (Danni)", 110, 77);
  pop();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

// Supporto Mouse (usa le stesse funzioni del pinch per coerenza)
function mousePressed() {
  // Simuliamo il pinchX e pinchY con mouseX e mouseY per il click del mouse
  pinchX = mouseX;
  pinchY = mouseY;
  pinchJustPressed = true;
  
  if (gameState === 'menu') checkMenuPinch();
  else if (gameState === 'playing') checkCloseButtonPinch();
  else if (gameState === 'paused') checkPausePinch();
  else if (gameState === 'gameover') checkGameOverPinch();
  
  pinchJustPressed = false;
}