let video;
let handpose;
let hands = [];
let player;
let items = [];
let score = 0;
let lives = 3;
let gameState = 'menu';
let spawnTimer = 0;
let spawnInterval = 100;

let imgSfondo;
let imgBuono;
let imgsCattivo = [];
let animDestra = [];
let animSinistra = [];
let currentFrame = 0;

// Variabili pinch
let pinched = false;
let pinchX = 0;
let pinchY = 0;

function preload() {
  imgSfondo = loadImage('immagini/sfondoScuola.jpg');
  imgBuono = loadImage('immagini/buono.png');
  imgsCattivo.push(loadImage('immagini/cattivo1.png'));
  imgsCattivo.push(loadImage('immagini/cattivo2.png'));
  for (let i = 1; i <= 4; i++) {
    animDestra.push(loadImage(`immagini/destra${i}.png`));
    animSinistra.push(loadImage(`immagini/sinistra${i}.png`));
  }
}

function setup() {
  createCanvas(windowWidth, windowHeight);

  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  let options = {
    maxHands: 1,
    runtime: 'mediapipe',
    flipHorizontal: false
  };

  handpose = ml5.handPose(video, options, () => {
    console.log("Sistema pronto!");
    handpose.detectStart(video, (results) => {
      hands = results;
    });
  });

  player = {
    x: width / 2,
    y: height - 200,
    size: 160,
    direction: 'destra'
  };
}

function draw() {
  image(imgSfondo, 0, 0, width, height);

  updatePinch(); // aggiorna lo stato del pinch ogni frame

  if (gameState === 'playing') {
    updateGame();
    drawGame();
    drawLegend();
    drawCloseButton(); // X per aprire pausa
    checkCloseButtonPinch();
  } else if (gameState === 'menu') {
    drawGame();
    drawMenuOverlay();
    checkMenuPinch();
  } else if (gameState === 'paused') {
    drawGame();
    drawPauseOverlay();
    checkPausePinch();
  } else if (gameState === 'gameover') {
    showGameOver();
    checkGameOverPinch();
  }

  // Disegna cursore mano
  drawHandCursor();
}

// ─── PINCH ───────────────────────────────────────────────────────────────────
let pinchJustPressed = false;
let prevPinched = false;

function updatePinch() {
  prevPinched = pinched;
  if (hands && hands.length > 0) {
    let hand = hands[0];
    let index = hand.keypoints[8];
    let thumb = hand.keypoints[4];

    // Specchio orizzontale come il personaggio
    let ix = width - map(index.x, 0, video.width, 0, width);
    let iy = map(index.y, 0, video.height, 0, height);
    let tx = width - map(thumb.x, 0, video.width, 0, width);
    let ty = map(thumb.y, 0, video.height, 0, height);

    let d = dist(ix, iy, tx, ty);
    pinchX = (ix + tx) / 2;
    pinchY = (iy + ty) / 2;

    pinched = d < 40;
  } else {
    pinched = false;
  }
  pinchJustPressed = pinched && !prevPinched;
}

function drawHandCursor() {
  if (hands && hands.length > 0) {
    fill(255, 255, 255, pinched ? 200 : 120);
    stroke(255);
    strokeWeight(2);
    ellipse(pinchX, pinchY, pinched ? 20 : 30);
    noStroke();
  }
}

// ─── BOTTONE X ───────────────────────────────────────────────────────────────
function getCloseButtonBounds() {
  return { x: width - 60, y: 15, w: 44, h: 44 };
}

function drawCloseButton() {
  let b = getCloseButtonBounds();
  let hovering = pinchX > b.x && pinchX < b.x + b.w && pinchY > b.y && pinchY < b.y + b.h;

  fill(hovering ? color(220, 60, 60) : color(180, 40, 40, 200));
  stroke(255, 255, 255, 80);
  strokeWeight(1.5);
  rect(b.x, b.y, b.w, b.h, 8);
  noStroke();

  fill(255);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(22);
  text("✕", b.x + b.w / 2, b.y + b.h / 2);
}

function checkCloseButtonPinch() {
  if (!pinchJustPressed) return;
  let b = getCloseButtonBounds();
  if (pinchX > b.x && pinchX < b.x + b.w && pinchY > b.y && pinchY < b.y + b.h) {
    gameState = 'paused';
  }
}

// ─── CHECK PINCH SUI BOTTONI ─────────────────────────────────────────────────
function checkMenuPinch() {
  if (!pinchJustPressed) return;
  let panH = 580;
  let panY = height / 2 - panH / 2;
  let btnW = 240, btnH = 56;
  let btnX = width / 2 - btnW / 2;
  let btnY = panY + 460;
  if (pinchX > btnX && pinchX < btnX + btnW && pinchY > btnY && pinchY < btnY + btnH) {
    startGame();
  }
}

function checkPausePinch() {
  if (!pinchJustPressed) return;
  let panH = 280;
  let panY = height / 2 - panH / 2;

  // X in alto a destra del pannello pausa
  let panW = 380;
  let panX = width / 2 - panW / 2;
  let xBtnSize = 36;
  let xBtnX = panX + panW - xBtnSize - 10;
  let xBtnY = panY + 10;
  if (pinchX > xBtnX && pinchX < xBtnX + xBtnSize && pinchY > xBtnY && pinchY < xBtnY + xBtnSize) {
    gameState = 'playing';
    return;
  }

  // Bottone RIPRENDI
  let btn1W = 240, btn1H = 50;
  let btn1X = width / 2 - btn1W / 2;
  let btn1Y = panY + 150;
  if (pinchX > btn1X && pinchX < btn1X + btn1W && pinchY > btn1Y && pinchY < btn1Y + btn1H) {
    gameState = 'playing';
    return;
  }

  // Bottone MENU
  let btn2W = 240, btn2H = 50;
  let btn2X = width / 2 - btn2W / 2;
  let btn2Y = panY + 215;
  if (pinchX > btn2X && pinchX < btn2X + btn2W && pinchY > btn2Y && pinchY < btn2Y + btn2H) {
    resetGame();
    gameState = 'menu';
  }
}

function checkGameOverPinch() {
  if (!pinchJustPressed) return;
  let btnW = 260, btnH = 56;
  let btnX = width / 2 - btnW / 2;
  let btnY = height / 2 + 80;
  if (pinchX > btnX && pinchX < btnX + btnW && pinchY > btnY && pinchY < btnY + btnH) {
    resetGame();
    gameState = 'playing';
  }
}

// ─── OVERLAY MENU INIZIALE ───────────────────────────────────────────────────
function drawMenuOverlay() {
  fill(0, 0, 0, 175);
  noStroke();
  rect(0, 0, width, height);

  let panW = min(560, width - 60);
  let panH = 580;
  let panX = width / 2 - panW / 2;
  let panY = height / 2 - panH / 2;

  fill(15, 15, 25, 220);
  stroke(255, 255, 255, 60);
  strokeWeight(1.5);
  rect(panX, panY, panW, panH, 16);
  noStroke();

  fill(255, 230, 80);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(38);
  text("🎒 ACCHIAPPA IL BISCOTTO!", width / 2, panY + 58);

  fill(200, 200, 220);
  textStyle(NORMAL);
  textSize(16);
  text("Usa la tua mano per muovere il personaggio!", width / 2, panY + 100);

  stroke(255, 255, 255, 40);
  strokeWeight(1);
  line(panX + 30, panY + 122, panX + panW - 30, panY + 122);
  noStroke();

  fill(255, 255, 255);
  textSize(19);
  textStyle(BOLD);
  textAlign(LEFT, CENTER);
  text("📋  REGOLE DI GIOCO", panX + 30, panY + 155);

  textStyle(NORMAL);
  textSize(14);
  fill(200, 200, 220);
  text("• Muovi la mano davanti alla webcam per spostare il personaggio.", panX + 30, panY + 188);
  text("• Hai 3 vite. Ogni oggetto cattivo che colpisci ne perdi una.", panX + 30, panY + 214);
  text("• Perdi tutte le vite = Game Over!", panX + 30, panY + 240);

  stroke(255, 255, 255, 40);
  line(panX + 30, panY + 262, panX + panW - 30, panY + 262);
  noStroke();

  fill(255, 255, 255);
  textSize(19);
  textStyle(BOLD);
  textAlign(LEFT, CENTER);
  text("🎯  OGGETTI", panX + 30, panY + 294);

  if (imgBuono) image(imgBuono, panX + 30, panY + 318, 44, 44);
  fill(100, 255, 130);
  textStyle(BOLD);
  textSize(15);
  text("+10 punti", panX + 86, panY + 330);
  fill(180, 230, 180);
  textStyle(NORMAL);
  textSize(13);
  text("Raccogli questi oggetti!", panX + 86, panY + 350);

  if (imgsCattivo[0]) image(imgsCattivo[0], panX + 30, panY + 376, 44, 44);
  if (imgsCattivo[1]) image(imgsCattivo[1], panX + 82, panY + 376, 44, 44);
  fill(255, 100, 100);
  textStyle(BOLD);
  textSize(15);
  text("-1 vita", panX + 138, panY + 388);
  fill(230, 180, 180);
  textStyle(NORMAL);
  textSize(13);
  text("Evita questi oggetti!", panX + 138, panY + 408);

  stroke(255, 255, 255, 40);
  line(panX + 30, panY + 435, panX + panW - 30, panY + 435);
  noStroke();

  // Bottone INIZIA — evidenziato se pinch sopra
  let btnW = 240, btnH = 56;
  let btnX = width / 2 - btnW / 2;
  let btnY = panY + 470;
  let hovering = pinchX > btnX && pinchX < btnX + btnW && pinchY > btnY && pinchY < btnY + btnH;
  fill(hovering ? color(255, 230, 50) : color(255, 200, 0));
  stroke(255, 255, 255, 100);
  strokeWeight(1.5);
  rect(btnX, btnY, btnW, btnH, 12);
  noStroke();
  fill(20, 20, 20);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(22);
  text("▶   INIZIA", width / 2, btnY + btnH / 2);

  fill(150, 150, 170);
  textStyle(NORMAL);
  textSize(12);
  text("Avvicina pollice e indice per cliccare", width / 2, panY + panH + 20);
}

// ─── OVERLAY PAUSA ───────────────────────────────────────────────────────────
function drawPauseOverlay() {
  fill(0, 0, 0, 160);
  noStroke();
  rect(0, 0, width, height);

  let panW = 380;
  let panH = 280;
  let panX = width / 2 - panW / 2;
  let panY = height / 2 - panH / 2;

  fill(15, 15, 25, 225);
  stroke(255, 255, 255, 60);
  strokeWeight(1.5);
  rect(panX, panY, panW, panH, 16);
  noStroke();

  // X in alto a destra del pannello
  let xBtnSize = 36;
  let xBtnX = panX + panW - xBtnSize - 10;
  let xBtnY = panY + 10;
  let xHover = pinchX > xBtnX && pinchX < xBtnX + xBtnSize && pinchY > xBtnY && pinchY < xBtnY + xBtnSize;
  fill(xHover ? color(220, 60, 60) : color(160, 40, 40, 180));
  stroke(255, 80);
  strokeWeight(1);
  rect(xBtnX, xBtnY, xBtnSize, xBtnSize, 6);
  noStroke();
  fill(255);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(18);
  text("✕", xBtnX + xBtnSize / 2, xBtnY + xBtnSize / 2);

  fill(255, 230, 80);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(40);
  text("⏸ PAUSA", width / 2, panY + 65);

  fill(200, 200, 220);
  textStyle(NORMAL);
  textSize(17);
  text("Punti: " + score + "   Vite: " + lives, width / 2, panY + 115);

  let btn1W = 240, btn1H = 50;
  let btn1X = width / 2 - btn1W / 2;
  let btn1Y = panY + 150;
  let hover1 = pinchX > btn1X && pinchX < btn1X + btn1W && pinchY > btn1Y && pinchY < btn1Y + btn1H;
  fill(hover1 ? color(255, 220, 30) : color(255, 200, 0));
  stroke(255, 255, 255, 80);
  strokeWeight(1);
  rect(btn1X, btn1Y, btn1W, btn1H, 10);
  noStroke();
  fill(20, 20, 20);
  textStyle(BOLD);
  textSize(18);
  text("▶  RIPRENDI", width / 2, btn1Y + btn1H / 2);

  let btn2W = 240, btn2H = 50;
  let btn2X = width / 2 - btn2W / 2;
  let btn2Y = panY + 215;
  let hover2 = pinchX > btn2X && pinchX < btn2X + btn2W && pinchY > btn2Y && pinchY < btn2Y + btn2H;
  fill(hover2 ? color(100, 100, 120) : color(60, 60, 80));
  stroke(255, 255, 255, 40);
  strokeWeight(1);
  rect(btn2X, btn2Y, btn2W, btn2H, 10);
  noStroke();
  fill(220, 220, 240);
  textStyle(BOLD);
  textSize(18);
  text("🏠  MENU PRINCIPALE", width / 2, btn2Y + btn2H / 2);
}

// ─── GAME LOGIC ──────────────────────────────────────────────────────────────
function updateGame() {
  if (hands && hands.length > 0) {
    let finger = hands[0].keypoints[9];
    let rawX = map(finger.x, 0, video.width, 0, width);
    let correctedX = width - rawX;

    let targetX = correctedX - player.size / 2;
    if (targetX > player.x + 2) player.direction = 'destra';
    else if (targetX < player.x - 2) player.direction = 'sinistra';

    player.x = lerp(player.x, targetX, 0.2);

    if (frameCount % 8 === 0) {
      currentFrame = (currentFrame + 1) % 4;
    }
  }

  spawnTimer++;
  if (spawnTimer >= spawnInterval) {
    spawnItem();
    spawnTimer = 0;
  }

  for (let i = items.length - 1; i >= 0; i--) {
    items[i].y += items[i].speed;

    let itemSize = 80;
    if (
      items[i].x < player.x + player.size * 0.75 &&
      items[i].x + itemSize > player.x + player.size * 0.25 &&
      items[i].y < player.y + player.size * 0.85 &&
      items[i].y + itemSize > player.y + player.size * 0.15
    ) {
      if (items[i].type === 'good') score += 10;
      else {
        lives--;
        if (lives <= 0) gameState = 'gameover';
      }
      items.splice(i, 1);
      continue;
    }
    if (items[i].y > height) items.splice(i, 1);
  }
}

function drawGame() {
  if (gameState === 'playing' || gameState === 'paused') {
    let imgToShow = (player.direction === 'destra') ? animDestra[currentFrame] : animSinistra[currentFrame];
    image(imgToShow, player.x, player.y, player.size, player.size);
  }

  for (let item of items) {
    image(item.img, item.x, item.y, 80, 80);
  }

  if (gameState === 'playing') {
    fill(0, 0, 0, 150);
    noStroke();
    rect(10, height - 75, 120, 65, 5);
    fill(255);
    textSize(22);
    textAlign(LEFT);
    textStyle(NORMAL);
    text("Punti: " + score, 20, height - 50);
    text("Vite: " + lives, 20, height - 20);
  }
}

function drawLegend() {
  push();
  fill(0, 0, 0, 160);
  noStroke();
  rect(10, 10, 250, 100, 10);
  image(imgBuono, 20, 20, 35, 35);
  fill(255);
  textSize(16);
  textAlign(LEFT, CENTER);
  textStyle(NORMAL);
  text("Prendi (Punti)", 70, 37);
  image(imgsCattivo[0], 20, 60, 35, 35);
  image(imgsCattivo[1], 60, 60, 35, 35);
  text("Evita (Danni)", 110, 77);
  pop();
}

function spawnItem() {
  let isGood = random() > 0.4;
  let imgSelezionata = isGood ? imgBuono : random(imgsCattivo);
  items.push({
    x: random(80, width - 80),
    y: -90,
    speed: random(3, 6),
    type: isGood ? 'good' : 'bad',
    img: imgSelezionata
  });
}

function showGameOver() {
  image(imgSfondo, 0, 0, width, height);
  fill(0, 0, 0, 200);
  noStroke();
  rect(0, 0, width, height);

  fill(255, 230, 80);
  textAlign(CENTER, CENTER);
  textStyle(BOLD);
  textSize(60);
  text("GAME OVER", width / 2, height / 2 - 40);

  fill(255);
  textStyle(NORMAL);
  textSize(25);
  text("Punteggio finale: " + score, width / 2, height / 2 + 30);

  let btnW = 260, btnH = 56;
  let btnX = width / 2 - btnW / 2;
  let btnY = height / 2 + 80;
  let hover = pinchX > btnX && pinchX < btnX + btnW && pinchY > btnY && pinchY < btnY + btnH;
  fill(hover ? color(255, 220, 30) : color(255, 200, 0));
  stroke(255, 255, 255, 80);
  strokeWeight(1);
  rect(btnX, btnY, btnW, btnH, 10);
  noStroke();
  fill(20, 20, 20);
  textStyle(BOLD);
  textSize(20);
  text("🔄  RIPROVA", width / 2, btnY + btnH / 2);
}

// ─── INPUT MOUSE (per chi non ha la mano) ────────────────────────────────────
function mousePressed() {
  if (gameState === 'menu') {
    let panH = 580;
    let panY = height / 2 - panH / 2;
    let btnW = 240, btnH = 56;
    let btnX = width / 2 - btnW / 2;
    let btnY = panY + 460;
    if (mouseX > btnX && mouseX < btnX + btnW && mouseY > btnY && mouseY < btnY + btnH) startGame();
  } else if (gameState === 'playing') {
    let b = getCloseButtonBounds();
    if (mouseX > b.x && mouseX < b.x + b.w && mouseY > b.y && mouseY < b.y + b.h) gameState = 'paused';
  } else if (gameState === 'paused') {
    let panW = 380, panH = 280;
    let panX = width / 2 - panW / 2;
    let panY = height / 2 - panH / 2;
    let xBtnSize = 36;
    let xBtnX = panX + panW - xBtnSize - 10;
    let xBtnY = panY + 10;
    if (mouseX > xBtnX && mouseX < xBtnX + xBtnSize && mouseY > xBtnY && mouseY < xBtnY + xBtnSize) { gameState = 'playing'; return; }
    let btn1W = 240, btn1H = 50, btn1X = width / 2 - 120, btn1Y = panY + 150;
    if (mouseX > btn1X && mouseX < btn1X + btn1W && mouseY > btn1Y && mouseY < btn1Y + btn1H) { gameState = 'playing'; return; }
    let btn2W = 240, btn2H = 50, btn2X = width / 2 - 120, btn2Y = panY + 215;
    if (mouseX > btn2X && mouseX < btn2X + btn2W && mouseY > btn2Y && mouseY < btn2Y + btn2H) { resetGame(); gameState = 'menu'; }
  } else if (gameState === 'gameover') {
    let btnW = 260, btnH = 56, btnX = width / 2 - 130, btnY = height / 2 + 80;
    if (mouseX > btnX && mouseX < btnX + btnW && mouseY > btnY && mouseY < btnY + btnH) { resetGame(); gameState = 'playing'; }
  }
}

function startGame() {
  resetGame();
  gameState = 'playing';
}

function resetGame() {
  score = 0;
  lives = 3;
  items = [];
  spawnTimer = 0;
  player.x = width / 2;
  player.direction = 'destra';
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}