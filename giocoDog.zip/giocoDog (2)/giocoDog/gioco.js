let video;
let handpose;
let hands = [];
let cursor = { x: 0, y: 0 };
let pinchState = false;
let ultimoPinch = false;

let imgSfondo, imgCono;
let imgsGelato = {}; 

// Variabili Musica
let musicaDoggo;
let musicStarted = false;

let coni = [
  ['marrone', 'giallo', 'verde', 'rosa'],
  ['verde', 'rosa', 'marrone', 'giallo'],
  ['giallo', 'marrone', 'rosa', 'verde'],
  ['marrone', 'giallo', 'verde', 'rosa'],
  [],
  []
];

let selezione = { attiva: false, indiceCono: -1, gusto: null };
let vittoria = false;

function preload() {
  imgSfondo = loadImage('sfondo.png');
  imgCono = loadImage('cono.png');
  imgsGelato['rosa'] = loadImage('rosa.png');
  imgsGelato['verde'] = loadImage('verde.png');
  imgsGelato['bianco'] = loadImage('bianco.png');
  imgsGelato['giallo'] = loadImage('giallo.png');
  imgsGelato['marrone'] = loadImage('marrone.png');
  
  // CARICAMENTO MUSICA
  musicaDoggo = loadSound('GiocoDoggo.mp3');
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  let options = { maxHands: 1, runtime: 'mediapipe', flipHorizontal: true };
  handpose = ml5.handPose(video, options, () => {
    console.log("Sistema Pronto!");
    handpose.detectStart(video, (results) => { hands = results; });
  });
}

function draw() {
  // Ridisegno sfondo per evitare scie
  if (imgSfondo) {
    imageMode(CORNER); 
    image(imgSfondo, 0, 0, width, height);
  } else {
    background(200, 230, 255); 
  }

  gestisciInputMano();
  
  // GESTIONE AVVIO MUSICA (al primo rilevamento mano)
  if (!musicStarted && hands.length > 0) {
    if (musicaDoggo && !musicaDoggo.isPlaying()) {
      musicaDoggo.loop();
      musicaDoggo.setVolume(0.3);
      musicStarted = true;
    }
  }

  gestisciPulsanteUscita();

  if (vittoria) {
    disegnaVittoria();
    if (musicaDoggo && musicaDoggo.isPlaying()) musicaDoggo.setVolume(0.1); // Abbassa musica a vittoria
    return;
  }

  // Layout 3 sopra e 3 sotto
  for (let i = 0; i < coni.length; i++) {
    let riga = Math.floor(i / 3); 
    let colonna = i % 3;
    let x = (width / 4) * (colonna + 1);
    let y = (riga === 0) ? height * 0.40 : height * 0.85;
    disegnaCono(i, x, y);
  }

  if (selezione.attiva) {
    imageMode(CENTER);
    image(imgsGelato[selezione.gusto], cursor.x, cursor.y, 100, 100);
  }

  disegnaCursore();
  
  ultimoPinch = pinchState;
  controllaVittoria();
}

function gestisciInputMano() {
  if (hands.length > 0) {
    let index = hands[0].keypoints[8];
    let thumb = hands[0].keypoints[4];
    // flipHorizontal è attivo, mappiamo correttamente
    cursor.x = map(index.x, 0, video.width, 0, width);
    cursor.y = map(index.y, 0, video.height, 0, height);
    let d = dist(index.x, index.y, thumb.x, thumb.y);
    pinchState = d < 40;
  }
}

function disegnaCursore() {
  if (hands.length > 0) {
    push();
    fill(pinchState ? "yellow" : "white");
    noStroke();
    ellipse(cursor.x, cursor.y, 15, 15);
    noFill();
    stroke(pinchState ? "yellow" : "white");
    strokeWeight(2);
    ellipse(cursor.x, cursor.y, 35, 35);
    pop();
  }
}

function disegnaCono(index, x, y) {
  imageMode(CENTER);
  let areaClick = 100;

  // Evidenziazione al passaggio
  if (dist(cursor.x, cursor.y, x, y - 80) < areaClick) {
    noFill();
    stroke(255, 255, 0, 150);
    strokeWeight(5);
    rectMode(CENTER);
    rect(x, y - 100, 140, 300, 20);
    
    if (pinchState && !ultimoPinch) {
      gestisciAzione(index);
    }
  }

  image(imgCono, x, y, 100, 180);
  
  for (let j = 0; j < coni[index].length; j++) {
    let gusto = coni[index][j];
    let pallinaY = (y - 80) - (j * 55); 
    image(imgsGelato[gusto], x, pallinaY, 90, 90);
  }
}

function gestisciAzione(index) {
  if (!selezione.attiva) {
    if (coni[index].length > 0) {
      selezione.gusto = coni[index].pop();
      selezione.indiceCono = index;
      selezione.attiva = true;
    }
  } else {
    let conoTarget = coni[index];
    let pieno = conoTarget.length >= 4;
    let vuoto = conoTarget.length === 0;
    let stessoColore = !vuoto && conoTarget[conoTarget.length - 1] === selezione.gusto;
    
    if (!pieno && (vuoto || stessoColore)) {
      conoTarget.push(selezione.gusto);
      selezione.attiva = false;
      selezione.gusto = null;
    } else if (index === selezione.indiceCono) {
      coni[index].push(selezione.gusto);
      selezione.attiva = false;
      selezione.gusto = null;
    }
  }
}

function gestisciPulsanteUscita() {
  let btnX = width - 60;
  let btnY = 60;
  let btnSize = 50;
  
  fill(200, 0, 0);
  stroke(255);
  strokeWeight(2);
  ellipse(btnX, btnY, btnSize, btnSize);
  
  stroke(255);
  strokeWeight(4);
  line(btnX - 12, btnY - 12, btnX + 12, btnY + 12);
  line(btnX + 12, btnY - 12, btnX - 12, btnY + 12);
  
  if (dist(cursor.x, cursor.y, btnX, btnY) < btnSize / 2) {
    if (pinchState && !ultimoPinch) {
      if (musicaDoggo) musicaDoggo.stop();
      location.reload(); 
    }
  }
}

function controllaVittoria() {
  let completati = 0;
  for (let c of coni) {
    if (c.length === 0) completati++;
    else if (c.length === 4 && c.every(v => v === c[0])) completati++;
  }
  if (completati === coni.length) vittoria = true;
}

function disegnaVittoria() {
  push();
  fill(0, 0, 0, 180);
  rectMode(CORNER);
  rect(0, 0, width, height);
  fill(255, 255, 0);
  textSize(80);
  textAlign(CENTER, CENTER);
  text("OTTIMO LAVORO!", width/2, height/2 - 50);
  fill(255);
  textSize(30);
  text("Hai completato tutti i gelati!", width/2, height/2 + 50);
  pop();
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}